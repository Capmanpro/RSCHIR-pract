<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Каталог товаров</title>
</head>
<body>
    <h1>Каталог товаров</h1>
    
    <br>
    <table>
        <tbody>
            <tr>
                <th>Название товара</th>
                <th>Цена</th>
                <th>Описание</th>
            </tr>

            <?php
                $mysqli = new mysqli("database", "root", "password123", "php_database");
                $table = $mysqli->query("SELECT * FROM services");
                foreach ($table as $row) {
                    echo "<tr><td>{$row['name']}</td><td>{$row['price']}</td><td>{$row['description']}</td></tr>";
                }
            ?>
        </tbody>
    </table>

    <p>
        <a href="/">на главную</a>
    </p>
</body>
</html>
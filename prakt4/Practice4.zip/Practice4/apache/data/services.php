<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Methods: PATCH");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

include_once "api/ServiceRepository.php";
$serviceRepository = new ServiceRepository();
$id = (isset($_GET['id'])) ? intval($_GET['id']) : null;

switch ($method):
    case "GET": {
        if (!empty($id)) {
            $serviceRepository->getById($id);
        } else {
            $serviceRepository->getAll();
        }
        break;
    }
    case "POST": {
        $serviceRepository->create();
        break;
    }
    case "PATCH": {
        if (!empty($id)) {
            $serviceRepository->update($id);
        }    
        break;
    }
    case "DELETE": {
        if (!empty($id)) {
            $serviceRepository->delete($id);
        }
        break;
    }
endswitch;
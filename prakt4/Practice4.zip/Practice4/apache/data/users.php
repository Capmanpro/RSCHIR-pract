<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Methods: PATCH");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

include_once "api/UserRepository.php";
$userRepository = new UserRepository();
$id = (isset($_GET['id'])) ? intval($_GET['id']) : '';

switch ($method):
    case "GET": {
        if (!empty($id)) {
            $userRepository->getById($id);
        } else {
            $userRepository->getAll();
        }
        break;
    }
    case "POST": {
        $userRepository->create();
        break;
    }
    case "PATCH": {
        if (!empty($id)) {
            $userRepository->update($id);
        }        
        break;
    }
    case "DELETE": {
        if (!empty($id)) {
            $userRepository->delete($id);
        }
        break;
    }
endswitch;
<?php

class User {
    public $id;
    public $name;
    public $login;
    public $password;
    public $role;

    public function __construct($name, $login, $password, $role) {
        $this->name = $name;
        $this->login = $login;
        $this->password = $password;
        $this->role = $role;    
    }
}

<?php

class Service {
    public $id;
    public $name;
    public $description;
    public $price;
}

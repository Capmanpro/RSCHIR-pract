CREATE DATABASE IF NOT EXISTS php_database;

CREATE USER IF NOT EXISTS 'root'@'%' IDENTIFIED BY 'password123';
GRANT ALL ON php_database.* TO 'root'@'%';
FLUSH PRIVILEGES;

USE php_database;

CREATE TABLE IF NOT EXISTS services (
    id INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description VARCHAR(100)
);

INSERT INTO services (name, price, description)
VALUES 
    ('RTX 4090', 150000, 'Palit Gamerock SUPEDDUPER Edition'),
    ('Iphone 15 Pro Max', 200000, 'Тот же айфон, но с быстрым тайп си ;)'),
    ('Samsung S23', 100000, 'Samsung S23 BTS Edition'),
    ('Iphone 15', 100000, 'Тот же айфон, но с медленным тайп си ;)');

CREATE TABLE IF NOT EXISTS users (
    id INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(80) NOT NULL,
    name VARCHAR(20),
    role VARCHAR(20)
);

INSERT INTO users (id, login, password, name, role)
VALUES 
    (1, 'admin', '$2y$10$zg8.a61TAaVe.IbijfV/9OcCK2mqWruVU9ZPDCt3LaV0kyfjIgj4K', 'Директор', 'admin'),
    (2, 'user', 'hash', 'Клиент', 'user');